// حماية نماذج التسجيل من فقد البيانات (لكل البرنامج):
// مسودة تلقائية على هذا الجهاز: لو خرجت قبل الحفظ ورجعت، تُستعاد البيانات لتكمل وتحفظ.
// (تنبيه المتصفح «Leave site?» قبل المغادرة أُزيل بطلب المستخدم 2026-11-14، فلا تُعِده.)
// يشمل نماذج الحفظ (POST) التي فيها خانتان أو أكثر للكتابة أو الاختيار، ولا يشمل البحث والتصفية،
// ولا أي نموذج فيه كلمة مرور، ولا ما عليه data-no-draft. المسودة تُمسح عند الحفظ أو بعد 7 أيام.
(() => {
    // cm-draft3: مسودات الإصدارات السابقة (cm-draft: و cm-draft2:) كانت تحفظ ما تملؤه الصفحة تلقائيًا كأنه كتابة المستخدم، فتُمسح.
    // الخانة التي تملؤها الصفحة بنفسها تحمل data-draft-auto ما دامت قيمتها تلقائية: تُحفظ فارغة في المسودة،
    // فتعيد الصفحة ملأها عند الاستعادة ولا تُحسب كتابة يدوية (وإلا توقف الملء التلقائي بعد أول استعادة).
    const PREFIX = 'cm-draft3:';
    try { Object.keys(window.localStorage).filter(key => key.startsWith('cm-draft:') || key.startsWith('cm-draft2:')).forEach(key => window.localStorage.removeItem(key)); } catch { }
    // آخر لمسة من المستخدم (ضغطة أو مفتاح): ما تغيّره الصفحة بنفسها بلا لمسة قبله لا يُعَد كتابة
    let lastTouch = 0;
    ['pointerdown', 'keydown'].forEach(type => document.addEventListener(type, event => { if (event.isTrusted) lastTouch = Date.now(); }, true));
    const MAX_AGE = 7 * 24 * 60 * 60 * 1000;
    const storage = (() => { try { const s = window.localStorage; s.setItem('cm-draft-test', '1'); s.removeItem('cm-draft-test'); return s; } catch { return null; } })();
    const SKIP_TYPES = new Set(['hidden', 'submit', 'button', 'reset', 'image', 'file', 'password']);
    const dirtyForms = new Set();
    let submitting = false;
    const submitted = new Set(), flushers = [];

    const fieldsOf = form => [...form.elements].filter(el => el.name && !el.disabled && !SKIP_TYPES.has(el.type) && el.name !== '__RequestVerificationToken');
    const isEntryForm = form => {
        if ((form.getAttribute('method') || 'get').toLowerCase() !== 'post') return false;
        if (form.hasAttribute('data-no-draft') || form.querySelector('input[type=password]')) return false;
        const typing = fieldsOf(form).filter(el => el.type !== 'checkbox' && el.type !== 'radio');
        return typing.length >= 2;
    };

    // مفتاح المسودة: الصفحة + النموذج (رقمه بين نماذج الصفحة أو id)
    const keyOf = (form, index) => PREFIX + location.pathname + location.search + '|' + (form.getAttribute('id') || form.getAttribute('action') || index);

    const read = form => {
        const data = {};
        fieldsOf(form).forEach(el => {
            if (el.type === 'checkbox' || el.type === 'radio') { if (el.checked) (data[el.name] ||= []).push(el.value); }
            else if (el.tagName === 'SELECT' && el.multiple) data[el.name] = [...el.selectedOptions].map(option => option.value);
            else data[el.name] = el.hasAttribute('data-draft-auto') ? '' : el.value;
        });
        return data;
    };

    const hasContent = (form, initial) => JSON.stringify(read(form)) !== initial;

    const restore = (form, data) => {
        fieldsOf(form).forEach(el => {
            if (!(el.name in data)) { if (el.type === 'checkbox' || el.type === 'radio') el.checked = false; return; }
            const value = data[el.name];
            // خانة مملوءة تلقائيًا الآن وقيمتها المحفوظة فارغة: تُترك كما ملأتها الصفحة (لا تُفرَّغ عند الاستعادة أو «تجاهلها»)
            if (el.hasAttribute('data-draft-auto') && value === '') return;
            if (el.type === 'checkbox' || el.type === 'radio') el.checked = Array.isArray(value) && value.includes(el.value);
            else if (el.tagName === 'SELECT' && el.multiple) [...el.options].forEach(option => option.selected = value.includes(option.value));
            else el.value = value;
            el.dispatchEvent(new Event('input', { bubbles: true }));
            el.dispatchEvent(new Event('change', { bubbles: true }));
        });
    };

    const ago = time => {
        const minutes = Math.max(1, Math.round((Date.now() - time) / 60000));
        return minutes < 60 ? `منذ ${minutes} دقيقة` : minutes < 1440 ? `منذ ${Math.round(minutes / 60)} ساعة` : `منذ ${Math.round(minutes / 1440)} يوم`;
    };

    const notice = (form, saved, key, initialData) => {
        const bar = document.createElement('div');
        bar.className = 'ui-flash form-draft-notice';
        bar.setAttribute('role', 'status');
        bar.innerHTML = '<i class="bi bi-clock-history" aria-hidden="true"></i> <span></span> <button type="button" class="ui-btn ui-btn--ghost">تجاهلها</button>';
        bar.querySelector('span').textContent = `استُعيدت بيانات كتبتها ولم تُحفظ (${ago(saved)}). راجعها ثم اضغط «حفظ».`;
        bar.querySelector('button').addEventListener('click', () => {
            try { storage?.removeItem(key); } catch { }
            restore(form, initialData);
            dirtyForms.delete(form);
            bar.remove();
        });
        form.prepend(bar);
    };

    // تنظيف المسودات القديمة
    if (storage) {
        try {
            Object.keys(storage).filter(key => key.startsWith(PREFIX)).forEach(key => {
                try { if (Date.now() - JSON.parse(storage.getItem(key)).t > MAX_AGE) storage.removeItem(key); } catch { storage.removeItem(key); }
            });
        } catch { }
    }

    document.querySelectorAll('form').forEach((form, index) => {
        if (!isEntryForm(form)) return;
        const key = keyOf(form, index);
        const initialData = read(form);
        let initial = JSON.stringify(initialData);

        // استعادة مسودة سابقة لهذه الصفحة
        if (storage) {
            try {
                const draft = JSON.parse(storage.getItem(key) || 'null');
                if (draft && draft.d && JSON.stringify(draft.d) !== initial) {
                    restore(form, draft.d);
                    notice(form, draft.t, key, initialData);
                    dirtyForms.add(form);
                }
            } catch { }
        }

        let timer = null;
        const remember = event => {
            if (submitting) return;
            // ملء تلقائي من الصفحة (سعر الخدمة، قيمة افتراضية...) قبل أن يكتب المستخدم شيئًا: يصير هو الأصل، فلا تنبيه ولا مسودة
            if (!event.isTrusted && Date.now() - lastTouch > 1500 && !dirtyForms.has(form)) { initial = JSON.stringify(read(form)); return; }
            if (hasContent(form, initial)) dirtyForms.add(form); else dirtyForms.delete(form);
            clearTimeout(timer);
            timer = setTimeout(() => {
                if (!storage) return;
                try {
                    if (hasContent(form, initial)) storage.setItem(key, JSON.stringify({ t: Date.now(), d: read(form) }));
                    else storage.removeItem(key);
                } catch { }
            }, 400);
        };
        form.addEventListener('input', remember);
        form.addEventListener('change', remember);
        // حفظ فوري عند مغادرة الصفحة، إلا النموذج الذي يُرسَل الآن (يُحفظ على الخادم)
        flushers.push(() => {
            if (!storage || submitted.has(form) || !dirtyForms.has(form)) return;
            try { storage.setItem(key, JSON.stringify({ t: Date.now(), d: read(form) })); } catch { }
        });
        form.addEventListener('submit', event => {
            // إن ألغى المستخدم رسالة التأكيد (data-confirm) لا يُعَد النموذج محفوظًا
            submitting = true;
            submitted.add(form);
            clearTimeout(timer);
            setTimeout(() => {
                if (event.defaultPrevented) { submitting = false; submitted.delete(form); return; }
                try { storage?.removeItem(key); } catch { }
                dirtyForms.delete(form);
            }, 0);
        });
    });

    // لا تنبيه «Leave site?» عند المغادرة (أُزيل بطلب المستخدم 2026-11-14): المسودة التلقائية تكفي لحماية ما كُتب.
    // قبل الخروج تُحفظ المسودة فورًا (المؤقت 400 مللي ثانية قد لا يكون انتهى).
    window.addEventListener('pagehide', () => flushers.forEach(flush => flush()));
})();
